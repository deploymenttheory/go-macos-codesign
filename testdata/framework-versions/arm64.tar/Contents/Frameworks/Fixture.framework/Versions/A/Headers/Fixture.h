int fixture(void);
